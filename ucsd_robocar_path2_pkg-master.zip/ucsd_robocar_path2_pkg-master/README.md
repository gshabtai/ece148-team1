# ucsd_robocar_path2_pkg 

<img src="ucsd_ros2_logos.png">

<div>
